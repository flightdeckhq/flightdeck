"""flightdeck-sensor: in-process agent observability for Flightdeck."""
